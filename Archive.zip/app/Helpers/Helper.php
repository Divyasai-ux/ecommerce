<?php
namespace App\Helpers;

// if(!function_exists('checkuser')){

// 	function checkuser($user_id){
// 		// dd($user_id);
// 		return $user_id;
// 	}
// }
class Helper{
	public function chkuser($user_id){
		dd($user_id);
	}
}
?>