<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1 style="color:red;">test</h1>
<img src="<?php echo e(url('images/assets/slider_2.jpg')); ?>">
</body>
</html><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/test.blade.php ENDPATH**/ ?>