	<?php $__env->startSection('title','Faqs'); ?>
	<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<!-- <?php echo e(Auth::user()->id); ?> -->
			<?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-6 mt-10">
				<p class="faq_question"><b>Q: <?php echo e($faq->question); ?></b></p>
				<p class="faq_answer"><span style="color: black;"><b>Ans:</b></span> <?php echo e($faq->answer); ?></p>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/faqs.blade.php ENDPATH**/ ?>