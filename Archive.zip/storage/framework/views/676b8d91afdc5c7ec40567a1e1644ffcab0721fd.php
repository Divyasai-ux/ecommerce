	<?php $__env->startSection('title','Contact Us'); ?>
	<?php $__env->startSection('content'); ?>
	<div class=" container-fluid px-4 mb-5">
                <div class="page-header row no-gutters py-4">
                  <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                    <h3 class="page-title">Contact Forms</h3>
                  </div>
                </div>
                <?php if(session()->has('message')): ?>
                  <div class="alert alert-success"><?php echo e(session()->get('message')); ?></div>
                <?php endif; ?>
                <div class="row">
                  <div class="col">
                    <div class="card card-small ">
                      <div class="card-body p-0 pb-3 text-center">
                        <table class="table mb-0">
                          <thead class="bg-light">
                            <tr>
                              <th scope="col" class="border-0">Name</th>
                              <th scope="col" class="border-0">Email</th>
                              <th scope="col" class="border-0">Contact</th>
                              <th scope="col" class="border-0">Message</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php if(empty($queries)): ?>
                            <tr>
                              <td style="text-align: center; font-size: 2em;">
                                No Queries!!
                              </td>
                            </tr>
                            <?php endif; ?>
                          <?php $__currentLoopData = $queries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($query->name); ?></td>
                              <td><?php echo e($query->email); ?></td>
                              <td><?php echo e($query->contact); ?></td>
                              <td><?php echo e($query->message); ?></td>
                              <!-- <td>
                                <a href="<?php echo e(route('admin.deletefaq',$query->id)); ?>">
                                  <button class="btn btn-danger"><i class="material-icons menu-icon">delete</i></button>
                                </a>
                              </td> -->
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/admin/contactus.blade.php ENDPATH**/ ?>