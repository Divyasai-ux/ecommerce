<div>
	<?php if(session()->has('message')): ?>
	<div class="bg-success" style="padding: 10px; color: white;"><?php echo e(session()->get('message')); ?></div>

	<?php elseif(session()->has('error')): ?>
	<div><?php echo e(session()->get('error')); ?></div>

	<?php endif; ?>
</div>


<?php if($errors->any()): ?>
<div>
	<ul>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($errors); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>
<?php endif; ?><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/components/alert.blade.php ENDPATH**/ ?>