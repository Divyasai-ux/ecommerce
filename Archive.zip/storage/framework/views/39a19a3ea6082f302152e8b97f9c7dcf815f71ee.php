<?php $__env->startSection('title','Company Information'); ?>
<?php $__env->startSection('content'); ?>
<!-- / .main-navbar -->
<div class="main-content-container container-fluid px-4">
  <!-- Page Header -->
  <div class="page-header row no-gutters py-4">
    <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
      <span class="text-uppercase page-subtitle">Company Information</span>
      <h3 class="page-title">Add Information</h3>
    </div>
  </div>

  <div class="row">
    <div class="col-lg-9 col-md-12">
      <div class="card card-small mb-3">
        <div class="card-body">
          <form class="add-new-post" method="post" action="<?php echo e(route('admin.companyinfopost')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <input type="text" name="city" autocomplete="off" class="form-control form-control-lg" placeholder="Enter City Name">
            </div>
            <div class="form-group">
              <input class="form-control form-control-lg mb-3" autocomplete="off" type="text" name="state" placeholder="Enter State">
            </div>
            <div class="form-group">
              <input class="form-control form-control-lg mb-3" autocomplete="off" type="text" name="address" placeholder="Enter Complete Address">
            </div>
            <div class="form-group">
              <input class="form-control form-control-lg mb-3" autocomplete="off" type="text" name="email" placeholder="Enter Email">
            </div>
            <div class="form-group">
              <input class="form-control form-control-lg mb-3" autocomplete="off" type="text" name="contact" placeholder="Enter Contact Number">
            </div>
            <button class="btn btn-success"  name="submit" style="float: right; color: white;">Submit</button>
          </form>
        </div>
      </div>
      <?php if(session()->has('success')): ?>
      <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
      <?php endif; ?>

      <?php if($errors->any()): ?>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger"><?php echo e($error); ?></div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </div>
  </div>
  <div class=" container-fluid px-4 mb-5">
    <div class="page-header row no-gutters py-4">
      <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
        <h3 class="page-title">Information Details</h3>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <div class="card card-small ">
          <div class="card-body p-0 pb-3 text-center">
            <table class="table mb-0">
              <thead class="bg-light">
                <tr>
                  <th scope="col" class="border-0">City</th>
                  <th scope="col" class="border-0">State</th>
                  <th scope="col" class="border-0">Address</th>
                  <th scope="col" class="border-0">email</th>
                  <th scope="col" class="border-0">Contact</th>
                  <th scope="col" class="border-0">Delete</th>
                </tr>
              </thead>
              <tbody>
               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $information): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                <td><?php echo e($information->city); ?></td>
                <td><?php echo e($information->state); ?></td>
                <td><?php echo e($information->address); ?></td>
                <td><?php echo e($information->email); ?></td>
                <td><?php echo e($information->contact); ?></td>
                <td><button class="btn btn-danger" onclick="event.preventDefault();
                if(confirm('Do you want of Delete this type')){
                  document.getElementById('category-delete-<?php echo e($information->id); ?>').submit();
                }
                "><i class="material-icons menu-icon">delete</i></td>
                <form hidden="" method="post" id="<?php echo e('category-delete-'.$information->id); ?>" action="<?php echo e(route('admin.companyinfodelete', $information->id)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                </form>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/admin/contactinfo.blade.php ENDPATH**/ ?>