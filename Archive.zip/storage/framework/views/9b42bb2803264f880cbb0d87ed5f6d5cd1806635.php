<?php $__env->startSection('title','Edit Product'); ?>
<?php $__env->startSection('content'); ?>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">Edit</span>
                <h3 class="page-title">Edit Product</h3>
              </div>
            </div>
            <!-- End Page Header -->
            <div class="row">
              <div class="col-lg-9 col-md-12">
                <!-- Add New Post Form -->
                 <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <div class="card card-small mb-3">
                  <div class="card-body">
                    <form class="add-new-post" method="post" action="<?php echo e(route('update.product',$productdetails->id)); ?>" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Product Name</span>
                            <input type="text" name="product_name" value="<?php echo e($productdetails->product_name); ?>" class="form-control" autocomplete="off" placeholder="Enter Product Name">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Product Category</span>
                           <select class="form-control" name="product_category_id" value="<?php echo e($productdetails->product_category_id); ?>">
                             <option disabled="" selected="" value="-1">--Select Category--</option>
                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                          </div>
                        </div>
                      </div>
                       <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Product Type</span>
                            <select class="form-control" name="product_sub_category_id" value="<?php echo e($productdetails->product_sub_category_id); ?>">
                              <option disabled="" selected="" value="-1">--Select Sub-Category--</option>
                              <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($sub_category->id); ?>"><?php echo e($sub_category->sub_category); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Product Price</span>
                            <input type="text" name="product_price" value="<?php echo e($productdetails->product_price); ?>" class="form-control" autocomplete="off" placeholder="Enter Product Price">
                          </div>
                        </div>
                      </div>
                       <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Product Description</span>
                            <textarea class="form-control" rows="6" value="<?php echo e($productdetails->product_description); ?>" name="product_description" placeholder="Enter Product Description"></textarea>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Product In-Short</span>
                            <textarea class="form-control" value="<?php echo e($productdetails->product_inshort); ?>" name="product_inshort" placeholder="Enter Product In-Short" rows="6"></textarea>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Picture</span>
                            <input type="file" name="photo1" class="form-control">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Picture</span>
                            <input type="file" name="photo2" class="form-control">
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Picture</span>
                            <input type="file" name="photo3" class="form-control">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Picture</span>
                            <input type="file" name="photo4" class="form-control">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <span>Video Url</span>
                            <input type="text" name="video" value="<?php echo e($productdetails->video); ?>" class="form-control" placeholder="Enter YouTube Video URL">
                          </div>
                        </div>
                      </div>
                      <button class="btn btn-success" name="submit" style="float: right; color: white;">Submit</button>
                    </form>
                  </div>
                  
                </div>
                <!-- / Add New Post Form -->
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/admin/editproduct.blade.php ENDPATH**/ ?>