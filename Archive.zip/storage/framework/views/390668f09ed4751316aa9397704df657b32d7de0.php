	<?php $__env->startSection('title','Products List'); ?>
	<?php $__env->startSection('content'); ?>
	<div class=" container-fluid px-4 mb-5">
                <div class="page-header row no-gutters py-4">
                  <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                    <h3 class="page-title">Products List</h3>
                  </div>
                </div>
                <?php if(session()->has('message')): ?>
                  <div class="alert alert-success"><?php echo e(session()->get('message')); ?></div>
                <?php endif; ?>
                <div class="row">
                  <div class="col">
                    <div class="card card-small ">
                      <div class="card-body p-0 pb-3 text-center">
                        <?php if(count($products)==0): ?>
                          <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding: 20px;">
                              <h2>No Products!!</h2>
                            </div>
                          </div> 
                        <?php else: ?>
                            
                        <table class="table mb-0">
                          <thead class="bg-light">
                            <tr>
                              <th scope="col" class="border-0">Product Name</th>
                              <th scope="col" class="border-0">Product Category</th>
                              <th scope="col" class="border-0">Product Price</th>
                              <th scope="col" class="border-0">View</th>
                            </tr>
                          </thead>
                          <tbody>
                            
                          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($product->product_name); ?></td>
                              <td><?php echo e($product->category); ?></td>
                              <td><?php echo e($product->product_price); ?></td>
                              <td>
                                <a href="<?php echo e(route('single.product',$product->id)); ?>">
                                  <button class="btn btn-success"><i class="material-icons menu-icon">visibility</i></button>
                                </a>
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/admin/productslist.blade.php ENDPATH**/ ?>