<?php $__env->startSection('title','Welcome to'); ?>
<?php $__env->startSection('content'); ?>
<?php $total = 0 ?>
<?php $__currentLoopData = (array) session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $total += $details['price'] * $details['quantity'] ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php

?>


<!-- <main class="ps-main" > -->
<div class="container">
  <div class="row" style="margin-top: 50px;">
    <div class="col-xl-4 col-lg-4 col-md-4" >
      <?php if(sizeof($delivery_address)): ?>
      <div class="address-box" style="padding: 20px; border:1px solid red; border-radius: 10px; width: auto;">
        <span><b><?php echo e($delivery_address[0]->name); ?></b></span>
        <br>
        <span><?php echo e($delivery_address[0]->address); ?>, <?php echo e($delivery_address[0]->landmark); ?></span>
        <ul>
          <li class="" style="display: inline-block; text-decoration:"><?php echo e($delivery_address[0]->state); ?> *</li>
          <li class="" style="display: inline-block;"><?php echo e($delivery_address[0]->city); ?> *</li>
          <li class="" style="display: inline;"><?php echo e($delivery_address[0]->pincode); ?></li>
        </ul>
        <span><?php echo e($delivery_address[0]->contact); ?></span>
        <br>
        <button class="btn btn-sm" style="margin-top: 10px;"><?php echo e($type); ?></button>
      </div>
      <?php else: ?>
      <div class="address-box" style="padding: 20px;  border-radius: 10px; width: auto;">
        <a href="<?php echo e(route('user.profile')); ?>"><button class="btn">Add Address</button></a>
      </div>
      <?php endif; ?>
    </div>
    <div class="col-lg-4 col-xl-4 col-md-4">
      <div class="pay-btn" align="center">
        <button style="padding-left: 40px; padding-right: 40px; " class="btn btn-primary btn-lg">Pay</button>
      </div>
    </div>
  </div>
</div>






  <div class="ps-checkout pt-80 pb-80" hidden="">
    <div class="ps-container">      
      <form class="ps-checkout__form" method="post" hidden="">
        <div class="row">
          <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ">
           <div class="ps-checkout__billing">
            <h3>Personal Detail</h3>
            <div class="form-group form-group--inline">
              <label>Name<span>*</span>
              </label>
              <input class="form-control" type="text">
            </div>
            <div class="form-group form-group--inline">
              <label>Contact No.<span>*</span>
              </label>
              <input class="form-control" type="text">
            </div>
            <div class="form-group form-group--inline">
              <label>Payment Number<span>*</span>
              </label>
              <input class="form-control" type="text">
            </div>
            <div class="form-group form-group--inline">
              <label>Email Address<span>*</span>
              </label>
              <input class="form-control" type="email">
            </div>
            <div class="form-group form-group--inline">
              <label>House/Building No.<span>*</span>
              </label>
              <input class="form-control" type="text">
            </div>
            <div class="form-group form-group--inline">
              <label>Complete Address<span>*</span>
              </label>
              <input class="form-control" type="text">
            </div>
            <div class="form-group form-group--inline">
              <label>State<span>*</span>
              </label>
              <select class="form-control">
                
                <option>State</option>
                
              </select>
            </div>
            <div class="form-group form-group--inline">
              <label>City<span>*</span>
              </label>
              <input class="form-control" type="text">
            </div>
            <div class="form-group form-group--inline">
              <label>Pincode<span>*</span>
              </label>
              <input class="form-control" type="text">
            </div>
            <h3 class="mt-40"> Addition information</h3>
            <div class="form-group form-group--inline textarea">
              <label>Order Notes</label>
              <textarea class="form-control" rows="5" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
          <div class="ps-checkout__order">
            <header>
              <h3>Your Order</h3>
            </header>
            <div class="content">
              <table class="table ps-checkout__products">
                <thead>
                  <tr>
                    <th class="text-uppercase">Product</th>
                    <th class="text-uppercase">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if(session('cart')): ?>
                  <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($details['name']); ?></td>
                    <td>₹<?php echo e($details['price'] * $details['quantity']); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  
                  <tr >
                    <td style="padding-top: 20px; font-size: 1.5em;"><strong>Amount:</strong></td>
                    <td style="padding-top: 20px; font-size: 1.5em;"><?php echo e($total); ?></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <footer>
              <h3>Payment Method</h3>
              <div class="form-group cheque">
                <div class="ps-radio">
                  <input class="form-control" type="radio" id="rdo01" name="payment" checked>
                  <label for="rdo01">Google Pay</label>
                  <p>Pay the amount via Google Pay in Number given Below</p>
                </div>
                <div class="ps-radio ps-radio--inline">
                  <input class="form-control" type="radio" name="payment2" checked id="rdo02">
                  <label for="rdo02" style="float: left;"></label>
                  <span style="float: right!important!;">9992020209</span>
                </div>
              </div>
              <div class="form-group paypal">
                <button class="ps-btn ps-btn--fullwidth" name="placeorder">Place Order<i class="ps-icon-next"></i></button>
              </div>
            </footer>
          </div>
                   <!--  <div class="ps-shipping">
                      <h3>FREE SHIPPING</h3>
                      <p>YOUR ORDER QUALIFIES FOR FREE SHIPPING.<br> <a href="#"> Singup </a> for free shipping on every order, every time.</p>
                    </div> -->
                  </div>
                </div>
              </form>
            </div>
          </div>
          <?php $__env->stopSection(); ?>
         
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/checkout.blade.php ENDPATH**/ ?>