<?php $__env->startSection('title','Product Types'); ?>
<?php $__env->startSection('content'); ?>
          <!-- / .main-navbar -->
          <div class="main-content-container container-fluid px-4">
            <!-- Page Header -->
            <div class="page-header row no-gutters py-4">
              <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                <span class="text-uppercase page-subtitle">States</span>
                <h3 class="page-title">Add New State</h3>
              </div>
            </div>

            <div class="row">
              <div class="col-lg-9 col-md-12">
                <div class="card card-small mb-3">
                  <div class="card-body">
                    <form class="add-new-post" method="post" action="<?php echo e(route('admin.statepost')); ?>">
                      <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <input type="text" name="state" autocomplete="off" class="form-control" placeholder="Enter State Name">
                      </div>
                      <div class="form-group">
                        <input class="form-control form-control-lg mb-3" autocomplete="off" type="text" name="price" placeholder="Delivery Charges">
                      </div>
                      	<button class="btn btn-success"  name="submit" style="float: right; color: white;">Submit</button>
                     
                    </form>
                  </div>
                </div>
               <?php if(session()->has('success')): ?>
                  <div class="alert alert-success"><?php echo e(session()->get('success')); ?></div>
               <?php endif; ?>
            </div>
          </div>
          <div class=" container-fluid px-4 mb-5">
                <div class="page-header row no-gutters py-4">
                  <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
                    <h3 class="page-title">State</h3>
                  </div>
                </div>
                 <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <div class="row">
                  <div class="col">
                    <div class="card card-small ">
                      <div class="card-body p-0 pb-3 text-center">
                        <table class="table mb-0">
                          <thead class="bg-light">
                            <tr>
                              <th scope="col" class="border-0">State</th>
                              <th scope="col" class="border-0">Price</th>
                              <th scope="col" class="border-0">Edit</th>
                              <th scope="col" class="border-0">Delete</th>
                            </tr>
                          </thead>
                          <tbody>
                           <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                            <td><?php echo e($state->state); ?></td>
                           <td><?php echo e($state->price); ?></td>
                            <td><button class="btn btn-primary"><i class="material-icons menu-icon">edit</i></button></td>

                            <td><button class="btn btn-danger" onclick="event.preventDefault();
                            if(confirm('Do you want of Delete this type')){
                              document.getElementById('category-delete-<?php echo e($state->id); ?>').submit();
                            }
                            "><i class="material-icons menu-icon">delete</i></td>
                            <form hidden="" method="post" id="<?php echo e('category-delete-'.$state->id); ?>" action="<?php echo e(route('product_type.delete', $state->id)); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('delete'); ?>
                            </form>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/puneetdudi/Documents/sites/organicora/resources/views/admin/states.blade.php ENDPATH**/ ?>