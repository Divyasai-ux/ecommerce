 <footer class="main-footer d-flex p-2 px-3 bg-white border-top">
            <ul class="nav" hidden="">
              <li class="nav-item">
                <a class="nav-link" href="#">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Services</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Products</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Blog</a>
              </li>
            </ul>
            <span class="copyright ml-auto my-auto mr-2">Copyright © 2020
              <a href="https://opopol.com" rel="nofollow">OPOPOL Analytics Pvt Ltd</a>
            </span>
          </footer>
        </main>
      </div>
    </div>
    
    <script src="{{url('admin/scripts/jquery/jquery.js')}}"></script>
    <script src="{{url('admin/scripts/js/popper.js')}}"></script>
    <script src="{{url('admin/scripts/js/bootstrap.min.js')}}"></script>
    <script src="{{url('admin/scripts/js/chart.min.js')}}"></script>
    <script src="https://unpkg.com/shards-ui@latest/dist/js/shards.min.js"></script>
    <script src="{{url('admin/scripts/js/sharrre.js')}}"></script>
    <script src="{{url('admin/scripts/extras.1.1.0.min.js')}}"></script>
    <script src="{{url('admin/scripts/shards-dashboards.1.1.0.min.js')}}"></script>
    <script src="{{url('admin/scripts/app/app-blog-overview.1.1.0.js')}}"></script>
    <script type="text/javascript" src="{{url('js/lightbox.js')}}"></script>
  </body>
</html>